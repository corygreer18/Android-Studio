package com.example.project02;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Query;




public class LoginActivity extends AppCompatActivity {
    EditText user;
    EditText pass;
    Button login;
    public String testUser = "testUser1";
    public String testPass= "testuser1";
    public String adUser = "admin2";
    public String adPass = "admin2";







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        user = findViewById(R.id.username);
        pass = findViewById(R.id.password);
        login = findViewById(R.id.login);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if((user.getText().toString().equals(testUser) && pass.getText().toString().equals(testPass))||
                        (user.getText().toString().equals(adUser) && user.getText().toString().equals(adPass))){
                    Intent myIntent = new Intent(LoginActivity.this,
                            LandingPage.class);
                    startActivity(myIntent);
                }else{
                    Toast.makeText(getApplicationContext(), "User not Found.", Toast.LENGTH_LONG).show();
                }
            }

        });


    }
}
