/*
* Hi so when i created this activity I was a little confused on how to use room database
* i spent a lot of time trying to figure it out but this is the best I could come up with.
* I think it runs I went to test it and my computer froze each time, i do not think it like android very much.
* I tried multiple emulators but that did not seem to help either.
* I was not really sure what to do, but I wanted to submit at least my best effort.
* */
package com.example.project02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button login_1;
    Button create;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login_1 =findViewById(R.id.login_button);
        create = findViewById(R.id.create_button);

        login_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(MainActivity.this,
                        LoginActivity.class);
                startActivity(myIntent);
            }
        });

    }
}