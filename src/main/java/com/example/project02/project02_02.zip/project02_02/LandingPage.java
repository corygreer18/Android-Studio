package com.example.project02;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LandingPage extends AppCompatActivity {

    EditText user;
    EditText pass;
    Button admin;
    public String testUser = "testUser1";
    public String testPass= "testuser1";
    public String adUser = "admin2";
    public String adPass = "admin2";
    public boolean isAdmin = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.landing_page);

        if((user.getText().toString().equals(testUser) && pass.getText().toString().equals(testPass))){
            Toast.makeText(getApplicationContext(), "testUser1", Toast.LENGTH_LONG).show();
            admin.setVisibility(View.INVISIBLE);

        }else if((user.getText().toString().equals(adUser) && pass.getText().toString().equals(adPass))){
            Toast.makeText(getApplicationContext(), "admin2", Toast.LENGTH_LONG).show();
            admin.setVisibility(View.VISIBLE);
        }


    }
}
